<?php include 'includes/header.php'; ?><?php	include 'includes/header_1.php';?><?php	include 'includes/header_3.php';  ?>
<!-- Banner Starts here -->
<div class="container-Fluid bannerInner">
	<div class="bannerInnerShade">
		<div class="innerMainHead wow zoomInUp">Health Checkups<span><a href="index.html">Home</a> - Health Checkups</span></div>
	</div>
	<img src="images/slide-1.jpg" width="100%" style="min-height: 360px;">
</div>
<!-- Ends here -->

<!-- About Us Starts here -->
<div class="container paddingMain">
<div class="mobilePadd">

	<div class="wow fadeOutUp">
		<button class="accordion"><i class="fa fa-plus-circle"></i> GENERAL HEALTH CHECKUP - Rs 999/-</button>
<div class="panel" style="display: block">
  <div class="row">
  	<div class="col-xs-4">
  		<img src="images/chkp1.jpg" alt="" class="img-responsive">
  	</div>
  	<div class="col-xs-7">
  		<ul>
  			<li>RANDOM BLOOD SUGAR</li>
			<li>BLOOD GROUPING AND Rh TYPING</li>
			<li>LIPID PROFILE</li>
			<li>THYROID SIMULATING HORMONE</li>
			<li>BLOOD UREA</li>
			<li>SERUM CREATININE</li>
			<li>SERUM BILIRUBIN (TOTAL, DIRECT & INDIRECT)</li>
			<li>SGPT</li>
			<li>X-RAY</li>
			<li>ECG</li>
			<li>COMPLETE URINE ANALYSIS</li>
			<li>CONSULTATION</li>
  		</ul>
  		<hr>
  		<a href="contactus.html" class="readMoreBtn" target="blank"><div> Get Now </div></a>
  	</div>
  </div>
</div>

<button class="accordion"><i class="fa fa-plus-circle"></i> PRE EMPLOYMENT HEALTH CHECK - Rs. 999/-</button>
<div class="panel">
 	
<div class="row">
  	<div class="col-xs-4">
  		<img src="images/chkp1.jpg" alt="" class="img-responsive">
  	</div>
  	<div class="col-xs-7">
  		<ul>
  			<li>COMPLETE BLOOD COUNT</li>
			<li>RANDOM BLOOD SUGAR</li>
			<li>BLOOD GROUPING AND Rh TYPING</li>
			<li>VIRAL MARKERS (HIV, HBSAg, HCV)</li>
			<li>SERUM BILIRUBIN (TOTAL, DIRECT & INDIRECT)</li>
			<li>SERUM CREATININE</li>
			<li>COMPLETE URINE ANALYSIS</li>
			<li>ECG</li>
			<li>CHEST X-RAY</li>
			<li>CONSULTATION</li>
  		</ul>
  		<hr>
  		<a href="contactus.html" class="readMoreBtn" target="blank"><div> Get Now </div></a>
  	</div>
  </div>
</div>

<button class="accordion"><i class="fa fa-plus-circle"></i> FEVER PROFILE - Rs. 999 /-</button>
<div class="panel">
  <div class="row">
  	<div class="col-xs-4">
  		<img src="images/chkp1.jpg" alt="" class="img-responsive">
  	</div>
  	<div class="col-xs-7">
  		<ul>
  			<li>COMPLETE BLOOD COUNT</li>
			<li>ESR</li>
			<li>PERIPHERAL SMEAR FOR ABNORMAL CELLS AND HAEMOPARASITES</li>
			<li>SMEAR FOR MALARIAL PARASITE</li>
			<li>WIDAL TEST</li>
			<li>COMPLETE URINE ANALYSIS</li>
			<li>CHEST X-RAY</li>
			<li>VIRAL MARKERS</li>
			<li>CONSULTATION</li>
  		</ul>
  		<hr>
  		<a href="contactus.html" class="readMoreBtn" target="blank"><div> Get Now </div></a>
  	</div>
  </div>
</div>
<button class="accordion"><i class="fa fa-plus-circle"></i> BASIC CARDIAC CHECK UP - Rs. 999 /-</button>
<div class="panel">
  <div class="row">
  	<div class="col-xs-4">
  		<img src="images/chkp1.jpg" alt="" class="img-responsive">
  	</div>
  	<div class="col-xs-7">
  		<ul>
  			<li>BLOOD SUGAR FASTING AND POST PRANDIAL</li>
			<li>Hb %</li>
			<li>LIPID PROFILE</li>
			<li>ECG</li>
			<li>2D ECHO</li>
			<li>CHEST X-RAY</li>
			<li>CONSULTATION</li>
  		</ul>
  		<hr>
  		<a href="contactus.html" class="readMoreBtn" target="blank"><div> Get Now </div></a>
  	</div>
  </div>
</div>
<button class="accordion"><i class="fa fa-plus-circle"></i> DIABETIC CHECKUP Rs. 1300 /-</button>
<div class="panel">
  <div class="row">
  	<div class="col-xs-4">
  		<img src="images/chkp1.jpg" alt="" class="img-responsive">
  	</div>
  	<div class="col-xs-7">
  		<h3>FIRST VISIT</h3>
  		<ul>
  			<li>COMPLETE BLOOD COUNT</li>
			<li>BLOOD SUGAR FASTING AND POST PRANDIAL</li>
			<li>GLYCOSYLATED HAEMOGLOBIN (HbA1C)</li>
			<li>SERUM ELECTROLYTES</li>
			<li>LIPID PROFILE</li>
			<li>TSH</li>
			<li>BLOOD UREA</li>
			<li>SERUM CREATININE</li>
			<li>SERUM BILIRUBIN (TOTAL, DIRECT & INDIRECT)</li>
			<li>SGPT, SGOT</li>
			<li>BMI</li>
			<li>ECG</li>
			<li>2D ECHO</li>
			<li>COMPLETE URINE ANALYSIS</li>
			<li>CONSULTATION</li>
  		</ul>
  		<hr>
  		<h3>MONTHLY FOR 10 MONTHS</h3>
	    <ul>
	    	<li>BLOOD SUGAR FASTING AND POST PRANDIAL</li>
	    	<li>CONSULTATION</li>
	    </ul>
	    <h3>LAST MONTH</h3>
	    <ul>
	    	<li>BLOOD SUGAR FASTING AND POST PRANDIAL</li>
		    <li>COMPLETE BLOOD COUNT</li>
		    <li>BLOOD UREA</li>
		    <li>SERUM CREATININE</li>
		    <li>CONSULTATION</li>
	    </ul>
  		<hr>
  		<a href="contactus.html" class="readMoreBtn" target="blank"><div> Get Now </div></a>
  	</div>
  </div>
</div>

<script>
	
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
            panel.style.display = "none";
        } else {
            panel.style.display = "block";
        }
    });
}
</script>
	</div>

</div>
</div>
<!-- ends here -->
<?php	include 'includes/footer.php';  ?>