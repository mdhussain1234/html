<?php include 'includes/header.php'; ?><?php	include 'includes/header_1.php';?><?php	include 'includes/header_3.php';  ?>
<!-- Banner Starts here -->
<div class="container-Fluid bannerInner">
	<div class="bannerInnerShade">
		<div class="innerMainHead wow zoomInUp"> Make a Appointment<span><a href="index.html">Home</a> -  Make a Appointment</span></div>
	</div>
	<img src="images/slide-1.jpg" width="100%" style="min-height: 360px;">
</div>
<!-- Ends here -->

<!-- About Us Starts here -->
<div class="container paddingMain">
<div class="mobilePadd">
<div class="row">
	<div class="col-xs-6 wow fadeInLeft">				
				
		<div class="padRow">
					<h1>Quick Contact</h1>
				</div>
				<div class="padRow formFont" style="background-color:#e9e9e9; padding:15px; border:1px solid #d9d9d9">
					<p>
					Name<br>
					<input type="text" value="" class="textBox"></p>
					<p>
					Email<br>
					<input type="text" value="" class="textBox"></p>
					<p>
					Phone<br>
					<input type="text" value="" class="textBox"></p>
					<p>
					Select Date<br>
					<input type="date" value="" class="textBox"></p>
					<p>
					Select Time<br>
					<input type="time" value="" class="textBox"></p>
					<p>
					Message<br>
					<textarea class="textBox" rows="4"></textarea>
					</p>
					<a href="#" class="readMoreBtn"><div> Submit </div></a>
				</div>
				
			</div>

			<div class="col-xs-6 wow fadeInRight" align="center">
				<img src="images/appointment.jpg" class="img-responsive"/>
			</div>

</div>
</div>
</div>
<!-- ends here -->
<?php	include 'includes/footer.php';  ?>