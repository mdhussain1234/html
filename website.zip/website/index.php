<?php include 'includes/header.php'; ?><?php include 'includes/header_popup.php';  ?><?php	include 'includes/header_1.php';?><?php	include 'includes/header_2.php';?><?php	include 'includes/header_3.php';  ?>

<!-- Banner Starts here -->
<div class="container-Fluid">
<div class="swiper-container hideBanner">
    <div class="swiper-wrapper">   
		<div class="swiper-slide">			
		     <img src="images/slide-0.jpg" alt="" class="changeSlideImg" width="100%"/>
		</div>
		<div class="swiper-slide">			
		     <img src="images/slide-4.jpg" alt="" class="changeSlideImg" width="100%"/>
		</div>
        <div class="swiper-slide">			
		     <img src="images/slide-1.jpg" alt="" class="changeSlideImg" width="100%"/>
		</div>
        <div class="swiper-slide">			
		     <img src="images/slide-2.jpg" alt="" class="changeSlideImg" width="100%"/>
		</div>
		<div class="swiper-slide">			
		     <img src="images/slide-3.jpg" alt="" class="changeSlideImg" width="100%"/>
		</div>
    </div>
    <!-- Add Pagination -->        
</div> 
</div>
<!-- Ends here -->

<!-- Block Starts here -->
<div class="container-Fluid " style="z-index: 999;">
<div class="mobilePadd">
<div class="container marginTop wow flipInX">
	<div class="blockshapeDiv-1 ">
		<div class="blockContentDiv ">
			<img src="images/shape-icon-1.png" width="40" class="shapeIcn">
			<div class="shapeHeading">Our Doctors</div>
			<p class="shapeContentDiv">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Suscipit vitae, veritatis</p>
		</div>
	</div>
	<div class="blockshapeDiv-2 ">
		<div class="blockContentDiv">
			<img src="images/shape-icon-2.png" width="40" class="shapeIcn">
			<div class="shapeHeading">Treatments</div>
			<p class="shapeContentDiv">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Suscipit vitae, veritatis</p>
		</div>
	</div>
	<div class="blockshapeDiv-3 ">
		<div class="blockContentDiv">
			<img src="images/shape-icon-3.png" width="40" class="shapeIcn">
			<div class="shapeHeading">Reimbursement</div>
			<p class="shapeContentDiv">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Suscipit vitae, veritatis</p>
		</div>
	</div>
	<div class="blockshapeDiv-4 ">
		<div class="blockContentDiv">
			<img src="images/shape-icon-4.png" width="40" class="shapeIcn">
			<div class="shapeHeading">Security</div>
			<p class="shapeContentDiv">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Suscipit vitae, veritatis</p>
		</div>
	</div>
</div>
</div>
</div>
<!-- ends here -->

<!-- About Us Starts here -->
<div class="container">
<div class="mobilePadd">
<div class="row">
	<div class="col-xs-5 wow fadeInLeft">
		<div class="padRow">
		<img src="images/about-img.jpg" width="100%">
		</div>
	</div>
	<div class="col-xs-6 paddingMain wow fadeInRight">
		<div class="padRow">
		<h1>About Us <span>What we are and our history</span></h1>
		<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting.</p>
		</div>
		<div class="padRow">
		<h1>Vision & Mision<span>Our goal and thoughts</span></h1>
		<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
		<a href="javascript:void();" class="readMoreBtn"><div>Read More</div></a>
		</div>
		
	</div>
</div>
</div>
</div>
<!-- ends here -->

<!-- Services Starts here -->
<div class="container-Fluid paddingMain services_bg">
<div class="mobilePadd">
<div class="container">	
<h2 class="alignCenter wow zoomInUp" style="padding-bottom:20px; color:#ffffff">Service We Offer<span>Our department & special service</span></h2>

<div class="row">
	<div class="col-xs-6 wow fadeInRight">
	<div class="padRow">
		<div class="serviceiconDiv">
		<img src="images/service-icon-1.png" width="100%">
		</div>
		<div class="serviceiconContDiv">
			<h2 class="headingTxt">Emergency Care</h2>
			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
		</div>
	</div>
	</div>

	<div class="col-xs-6 wow fadeInLeft">
	<div class="padRow">
		<div class="serviceiconDiv">
		<img src="images/service-icon-2.png" width="100%">
		</div>
		<div class="serviceiconContDiv">
			<h2 class="headingTxt">Call Center 24/7</h2>
			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
		</div>
	</div>
	</div>

	<div class="col-xs-6 wow fadeInRight">
	<div class="padRow">
		<div class="serviceiconDiv">
		<img src="images/service-icon-3.png" width="100%">
		</div>
		<div class="serviceiconContDiv">
			<h2 class="headingTxt">Heart disease</h2>
			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
		</div>
	</div>
	</div>

	<div class="col-xs-6 wow fadeInLeft">
	<div class="padRow">
		<div class="serviceiconDiv">
		<img src="images/service-icon-4.png" width="100%">
		</div>
		<div class="serviceiconContDiv">
			<h2 class="headingTxt">Blood Test</h2>
			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
		</div>
	</div>
	</div>

</div>
<div class="alignCenter wow pulse"><a href="javascript:void();" class="readMoreBtn"><div>Read More</div></a></div>
</div>
</div>
</div>
<!-- ends here -->

<!-- Experts Starts here -->
<div class="container paddingMain">	
<div class="mobilePadd">
<h2 class="alignCenter  wow zoomInUp" style="padding-bottom:20px;">Expert Doctors<span>Our department & special service</span></h2>

<div class="row wow swing">
	<div class="col-xs-3">
	<div class="padRow">
		<div class="expertDocBlk">
			<div style="position:absolute; bottom: 0px;"><img src="images/expert-shape.png" width="100%"></div>
			<img src="images/expert-doc.jpg" width="100%">
		</div>
		<div class="expertDocContent">
			John Dote <span>Cardiologists</span>
		</div>
	</div>
	</div>

	<div class="col-xs-3">
	<div class="padRow">
		<div class="expertDocBlk">
			<div style="position:absolute; bottom: 0px;"><img src="images/expert-shape.png" width="100%"></div>
			<img src="images/expert-doc.jpg" width="100%">
		</div>
		<div class="expertDocContent">
			John Dote <span>Cardiologists</span>
		</div>
	</div>
	</div>

	<div class="col-xs-3">
	<div class="padRow">
		<div class="expertDocBlk">
			<div style="position:absolute; bottom: 0px;"><img src="images/expert-shape.png" width="100%"></div>
			<img src="images/expert-doc.jpg" width="100%">
		</div>
		<div class="expertDocContent">
			John Dote <span>Cardiologists</span>
		</div>
	</div>
	</div>

	<div class="col-xs-3">
	<div class="padRow">
		<div class="expertDocBlk">
			<div style="position:absolute; bottom: 0px;"><img src="images/expert-shape.png" width="100%"></div>
			<img src="images/expert-doc.jpg" width="100%">
		</div>
		<div class="expertDocContent">
			John Dote <span>Cardiologists</span>
		</div>
	</div>
	</div>
</div>
<div class="alignCenter clearFix wow pulse" style="padding-top:20px;">
	<a href="javascript:void();" class="readMoreBtn"><div>Read More</div></a></div>
</div>
</div>
<!-- ends here -->

<!-- Testimonial Starts here -->
<div class="container-Fluid testimonialBg">
<div class="container">
<div class="mobilePadd">
<div class="row">
	<div class="col-xs-4 wow rotateIn">
		<div class="padRow" style="padding: 0px 15px;">
		<img src="images/testimonial-image.png" width="100%" style="vertical-align: middle;">
		</div>
	</div>
	<div class="col-xs-8 testPaddTop  wow fadeOutUp">
		<div class="padRow">
			<h2 class="testimonialHDNG">Customer Comments</h2>
			<div class="testiContDiv">
				<div class="quoteDiv"><img src="images/quotes.png" width="25"></div>
				<p>All the lorem ipsum generators on the internet tend to repeat predefined chunks as necessary, making this the first true on the Internet. uses a dictionary of over.</p>
				<p class="authorName">- William Smith, <span>Advocate</span></p>
			</div>
		</div>
	</div>
</div>
</div>
</div>
</div>
<!-- ends here -->
<?php include 'includes/footer.php'; ?>