<?php include 'includes/header.php'; ?><?php	include 'includes/header_1.php';?><?php	include 'includes/header_3.php';  ?>
<!-- Banner Starts here -->
<div class="container-Fluid bannerInner">
	<div class="bannerInnerShade">
		<div class="innerMainHead wow zoomInUp">Photos <span><a href="index.html">Home</a> - Gallery</span></div>
	</div>
	<img src="images/slide-1.jpg" width="100%" style="min-height: 360px;">
</div>
<!-- Ends here -->

<!-- About Us Starts here -->
<div class="container">
<div class="mobilePadd">

<br>
<div class="row ">
	<div class="row gallery">
	
	<div class="col-xs-4 wow rotateIn">
		<div class="padRow">
			<a data-fancybox="gallery" href="images/slide-1.jpg"><img src="images/slide-1.jpg" class="img-responsive img-thumbnail" width="100%"></a>
		</div>
	</div>
	<div class="col-xs-4 wow rotateIn">
		<div class="padRow">
		<a data-fancybox="gallery" href="images/slide-2.jpg"><img src="images/slide-2.jpg" class="img-responsive img-thumbnail" width="100%"></a>
		</div>
	</div>
	<div class="col-xs-4 wow rotateIn">
		<div class="padRow">
		<a data-fancybox="gallery" href="images/slide-3.jpg"><img src="images/slide-3.jpg" class="img-responsive img-thumbnail" width="100%"></a>
		</div>
	</div>

	<div class="col-xs-4 wow rotateIn">
		<div class="padRow">
		<a data-fancybox="gallery" href="images/slide-1.jpg"><img src="images/slide-1.jpg" class="img-responsive img-thumbnail" width="100%"></a>
		</div>
	</div>
	<div class="col-xs-4 wow rotateIn">
		<div class="padRow">
		<a data-fancybox="gallery" href="images/slide-2.jpg"><img src="images/slide-2.jpg" class="img-responsive img-thumbnail" width="100%"></a>
		</div>
	</div>
	<div class="col-xs-4 wow rotateIn">
		<div class="padRow">
		<a data-fancybox="gallery" href="images/slide-3.jpg"><img src="images/slide-3.jpg" class="img-responsive img-thumbnail" width="100%"></a>
		</div>
	</div>


</div>
	<div class="clearFix">&nbsp;</div>
	
	
</div>

<br><br><br><br>



</div>
</div>
<!-- ends here -->
<?php	include 'includes/footer.php';  ?>