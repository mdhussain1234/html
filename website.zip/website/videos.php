<?php include 'includes/header.php'; ?><?php	include 'includes/header_1.php';?><?php	include 'includes/header_3.php';  ?>
<!-- Banner Starts here -->
<div class="container-Fluid bannerInner">
	<div class="bannerInnerShade">
		<div class="innerMainHead wow zoomInUp">Videos <span><a href="index.html">Home</a> - Gallery</span></div>
	</div>
	<img src="images/slide-1.jpg" width="100%" style="min-height: 360px;">
</div>
<!-- Ends here -->

<!-- About Us Starts here -->
<div class="container">
<div class="mobilePadd">

<br>
<div class="row ">
	<div class="row gallery">
	
	<div class="col-xs-3 wow rotateIn">
		<iframe width="100%" height="250" src="https://www.youtube.com/embed/bKTtTFthpis" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	</div>

	<div class="col-xs-3 wow rotateIn">
		<iframe width="100%" height="250" src="https://www.youtube.com/embed/bKTtTFthpis" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	</div>

	<div class="col-xs-3 wow rotateIn">
		<iframe width="100%" height="250" src="https://www.youtube.com/embed/bKTtTFthpis" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	</div>

	<div class="col-xs-3 wow rotateIn">
		<iframe width="100%" height="250" src="https://www.youtube.com/embed/bKTtTFthpis" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	</div>


	<div class="clearFix">&nbsp;</div>
	
	
	
	
	<div class="col-xs-3 wow rotateIn">
		<iframe width="100%" height="250" src="https://www.youtube.com/embed/bKTtTFthpis" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	</div>

	


</div>
	<div class="clearFix">&nbsp;</div>
	
	
</div>

<br><br><br><br>



</div>
</div>
<!-- ends here -->
<?php	include 'includes/footer.php';  ?>