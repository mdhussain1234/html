<?php include 'includes/header.php'; ?><?php	include 'includes/header_1.php';?><?php	include 'includes/header_3.php';  ?>
<!-- Banner Starts here -->
<div class="container-Fluid bannerInner">
	<div class="bannerInnerShade">
		<div class="innerMainHead wow zoomInUp">Contact Us<span><a href="index.html">Home</a> - Contact Us</span></div>
	</div>
	<img src="images/slide-1.jpg" width="100%" style="min-height: 360px;">
</div>
<!-- Ends here -->

<!-- About Us Starts here -->
<div class="container paddingMain">
<div class="mobilePadd">
<div class="row">
	<div class="col-xs-6 wow fadeInLeft">				
				<div class="padRow">
					<div class="logoDiv" style="display:;"><img src="images/ascent-hospital-logo-footer.jpg" alt="Ascent Hospital" title="Ascent Hospital" width="100%"></div>
					<div class="clearFix">
				
					<p><b>Address:</b> <br> Door No 46-22-19, Ramalayam Junction, Dhanalakshmi Textile Street, Syamala Nagar, Rajahmundry - 533103</p>
					
						<p><b>Phone :</b> 0883-2428055, 2420101</p>
						<p><b>Mobile :</b> 076718 41424</p>
					</div>
					<div>
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3815.334946608434!2d81.78949731434831!3d17.007232918135195!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a37a3ed3acd30b9%3A0xd887b3b37e0ab2e3!2sAscent+Cancer+And+Multispecialty+Hospital!5e0!3m2!1sen!2sin!4v1541418944572" width="100%" height="250" frameborder="0" style="border:0" allowfullscreen></iframe>
					
				
					</div>
				</div>				
			</div>

			<div class="col-xs-6 wow fadeInRight">
				<div class="padRow">
					<h1>Quick Contact</h1>
				</div>
				<div class="padRow formFont" style="background-color:#e9e9e9; padding:15px; border:1px solid #d9d9d9">
					<p>
					Name<br>
					<input type="text" value="" class="textBox"></p>
					<p>
					Email<br>
					<input type="text" value="" class="textBox"></p>
					<p>
					Phone<br>
					<input type="text" value="" class="textBox"></p>
					<p>
					Message<br>
					<textarea class="textBox" rows="4"></textarea>
					</p>
					<a href="#" class="readMoreBtn"><div> Submit </div></a>
				</div>
			</div>

</div>
</div>
</div>
<!-- ends here -->
<?php	include 'includes/footer.php';  ?>