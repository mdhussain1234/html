<?php include 'includes/header.php'; ?><?php	include 'includes/header_1.php';?><?php	include 'includes/header_3.php';  ?>

<!-- Banner Starts here -->
<div class="container-Fluid bannerInner">
	<div class="bannerInnerShade">
		<div class="innerMainHead wow zoomInUp">Lung Cancer Surgeries <span><a href="index.html">Home</a> - Treatments</span></div>
	</div>
	<img src="images/slide-1.jpg" width="100%" style="min-height: 360px;">
</div>
<!-- Ends here -->

<!-- About Us Starts here -->
<div class="container">
<div class="mobilePadd">

<br>
<div class="row ">
	<div class="row">
	<div class="col-xs-8 wow fadeInLeft">
	
		<p align="justify">
			Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse vulputate risus quis suscipit sodales. Nam eros dui, auctor sed posuere vel, malesuada fermentum ante. Nullam tincidunt ligula dolor. Nullam tincidunt a metus vitae volutpat. Mauris ac orci risus. Integer laoreet faucibus bibendum. Ut dignissim accumsan orci, vel accumsan mi mattis vitae. Vestibulum sit amet est sem. Sed in finibus nibh. Nunc eu libero nisl. Suspendisse potenti. Vivamus finibus consequat urna, vel fermentum nisi dictum nec. Proin dapibus pellentesque est id ullamcorper. Duis condimentum et quam et tincidunt.
		</p>
		
		<p align="justify">Cras non nibh pharetra ipsum elementum tincidunt eget in diam. Praesent finibus sapien feugiat odio tincidunt lobortis. Proin gravida pretium ante eget ultricies. Curabitur ac ante justo. Maecenas blandit, libero eu consectetur finibus, nibh neque faucibus libero, eu pharetra diam tortor id est. Nulla finibus a mi quis facilisis. Curabitur maximus vestibulum sapien, eget porttitor metus pellentesque et. Etiam odio sem, commodo sed mauris eget, hendrerit hendrerit ligula.</p>
		
		<p align="justify">
			Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse vulputate risus quis suscipit sodales. Nam eros dui, auctor sed posuere vel, malesuada fermentum ante. Nullam tincidunt ligula dolor. Nullam tincidunt a metus vitae volutpat. Mauris ac orci risus. Integer laoreet faucibus bibendum. Ut dignissim accumsan orci, vel accumsan mi mattis vitae. Vestibulum sit amet est sem. Sed in finibus nibh. Nunc eu libero nisl. Suspendisse potenti. Vivamus finibus consequat urna, vel fermentum nisi dictum nec. Proin dapibus pellentesque est id ullamcorper. Duis condimentum et quam et tincidunt.
		</p>
	
	
	<p align="justify">Cras non nibh pharetra ipsum elementum tincidunt eget in diam. Praesent finibus sapien feugiat odio tincidunt lobortis. Proin gravida pretium ante eget ultricies. Curabitur ac ante justo. Maecenas blandit, libero eu consectetur finibus, nibh neque faucibus libero, eu pharetra diam tortor id est. Nulla finibus a mi quis facilisis. Curabitur maximus vestibulum sapien, eget porttitor metus pellentesque et. Etiam odio sem, commodo sed mauris eget, hendrerit hendrerit ligula.</p>
		
		<p align="justify">
			Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse vulputate risus quis suscipit sodales. Nam eros dui, auctor sed posuere vel, malesuada fermentum ante. Nullam tincidunt ligula dolor. Nullam tincidunt a metus vitae volutpat. Mauris ac orci risus. Integer laoreet faucibus bibendum. Ut dignissim accumsan orci, vel accumsan mi mattis vitae. Vestibulum sit amet est sem. Sed in finibus nibh. Nunc eu libero nisl. Suspendisse potenti. Vivamus finibus consequat urna, vel fermentum nisi dictum nec. Proin dapibus pellentesque est id ullamcorper. Duis condimentum et quam et tincidunt.
		</p>
	</div>

	<div class="col-xs-4 wow fadeInRight">
	<div class="enquiry_bg">
		<div class="">
					<h1>Quick Contact</h1>
				</div>
				<div class=" formFont">
					<p>
					Name<br>
					<input type="text" value="" class="textBox"></p>
					<p>
					Email<br>
					<input type="text" value="" class="textBox"></p>
					<p>
					Phone<br>
					<input type="text" value="" class="textBox"></p>
					<p>
					Message<br>
					<textarea class="textBox" rows="4"></textarea>
					</p>
					<a href="#" class="readMoreBtn"><div> Submit </div></a>
				</div>
				</div>
				
				<br>
				
				<iframe width="100%" height="315" src="https://www.youtube.com/embed/WHFRCrPj0SQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
				
			
	</div>


</div>
	<div class="clearFix"></div>
	
	
</div>

<br><br><br><br>



</div>
</div>
<!-- ends here -->
<?php	include 'includes/footer.php';  ?>