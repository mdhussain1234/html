<?php include 'includes/header.php'; ?><?php	include 'includes/header_1.php';?><?php	include 'includes/header_3.php';  ?>
<!-- Banner Starts here -->
<div class="container-Fluid bannerInner">
	<div class="bannerInnerShade">
		<div class="innerMainHead wow zoomInUp">Services <span><a href="index.html">Home</a> - Services</span></div>
	</div>
	<img src="images/slide-1.jpg" width="100%" style="min-height: 360px;">
</div>
<!-- Ends here -->

<!-- About Us Starts here -->
<div class="container">
<div class="mobilePadd">

<br>
<div class="row ">
	<div class="row">
	<div class="col-xs-3 wow flipInY">
		<div class="img-thumbnail" align="center">
		<img src="images/service1.jpg" class="img-responsive"/>
		<h3>General Surgery</h3>
		</div>
		
	</div>

	<div class="col-xs-3 wow flipInY">
		<div class="img-thumbnail" align="center">
		<img src="images/service2.jpg" class="img-responsive"/>
		<h3>Gastrointestinal Surgery</h3>
		</div>
		
	</div>
	
	<div class="col-xs-3 wow flipInY">
		<div class="img-thumbnail" align="center">
		<img src="images/service3.jpg" class="img-responsive"/>
		<h3>Neurosurgery</h3>
		</div>
		
	</div>
	
	<div class="col-xs-3 wow flipInY">
		<div class="img-thumbnail" align="center">
		<img src="images/service4.jpg" class="img-responsive"/>
		<h3>Laparoscopic Surgery</h3>
		</div>
		
	</div>


</div>
	<div class="clearFix">&nbsp;</div>
	
	<div class="row">
	<div class="col-xs-3 wow flipInY">
		<div class="img-thumbnail" align="center">
		<img src="images/service5.jpg" class="img-responsive"/>
		<h3>Bariatric Surgery</h3>
		</div>
		
	</div>

	<div class="col-xs-3 wow flipInY">
		<div class="img-thumbnail" align="center">
		<img src="images/service6.jpg" class="img-responsive"/>
		<h3>Urology</h3>
		</div>
		
	</div>
	
	<div class="col-xs-3 wow flipInY">
		<div class="img-thumbnail" align="center">
		<img src="images/service7.jpg" class="img-responsive"/>
		<h3>Trauma (Accident)</h3>
		</div>
		
	</div>
	
	<div class="col-xs-3 wow flipInY">
		<div class="img-thumbnail" align="center">
		<img src="images/service8.jpg" class="img-responsive"/>
		<h3>Plastic Surgery</h3>
		</div>
		
	</div>


</div>
	
	
	
	
	<div class="clearFix">&nbsp;</div>
	
	<div class="row">
	<div class="col-xs-3 wow flipInY">
		<div class="img-thumbnail" align="center">
		<img src="images/service9.jpg" class="img-responsive"/>
		<h3>General Medicine</h3>
		</div>
		
	</div>

	<div class="col-xs-3 wow flipInY">
		<div class="img-thumbnail" align="center">
		<img src="images/service10.jpg" class="img-responsive"/>
		<h3>Surgical Oncology (Cancer Surgery)</h3>
		</div>
		
	</div>
	
	<div class="col-xs-3 wow flipInY">
		<div class="img-thumbnail" align="center">
		<img src="images/service11.jpg" class="img-responsive"/>
		<h3>Medical Oncology (Chemotherapy)</h3>
		</div>
		
	</div>
	
	<div class="col-xs-3 wow flipInY">
		<div class="img-thumbnail" align="center">
		<img src="images/service12.jpg" class="img-responsive"/>
		<h3>Cancer Screening</h3>
		</div>
		
	</div>


</div>
	
	
	
	
	<div class="clearFix">&nbsp;</div>
	
	<div class="row">
	<div class="col-xs-3 wow flipInY">
		<div class="img-thumbnail" align="center">
		<img src="images/service13.jpg" class="img-responsive"/>
		<h3>Cancer Counseling</h3>
		</div>
		
	</div>

	<div class="col-xs-3 wow flipInY">
		<div class="img-thumbnail" align="center">
		<img src="images/service14.jpg" class="img-responsive"/>
		<h3>Pain Management</h3>
		</div>
		
	</div>
	



</div>
	
	
	
	<div class="clearFix">&nbsp;</div>
	<div class="clearFix">&nbsp;</div>
	<div class="clearFix">&nbsp;</div>
	
	
	
</div>




</div>


<br><br><br><br>
</div>
<!-- ends here -->
<?php	include 'includes/footer.php';  ?>