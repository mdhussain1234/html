<?php include 'includes/header.php'; ?><?php	include 'includes/header_1.php';?><?php	include 'includes/header_3.php';  ?>

<!-- Banner Starts here -->
<div class="container-Fluid bannerInner">
	<div class="bannerInnerShade">
		<div class="innerMainHead wow zoomInUp">Faq's<span><a href="index.html">Home</a> - Faqs</span></div>
	</div>
	<img src="images/slide-1.jpg" width="100%" style="min-height: 360px;">
</div>
<!-- Ends here -->

<!-- About Us Starts here -->
<div class="container paddingMain">
<div class="mobilePadd">

	<div class="faqList wow fadeOutUp">
	<ul>
		<li><h2>1.What is Lorem Ipsum?</h2>
		<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p></li>

		<li><h2>1.What is Lorem Ipsum?</h2>
		<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p></li>

		<li><h2>1.What is Lorem Ipsum?</h2>
		<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p></li>

		<li><h2>1.What is Lorem Ipsum?</h2>
		<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p></li>
		
		<li><h2>1.What is Lorem Ipsum?</h2>
		<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p></li>
	</ul>
	</div>

</div>
</div>
<!-- ends here -->
<?php	include 'includes/footer.php';  ?>