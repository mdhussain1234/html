
<!-- Sticky Header Starts Here -->

<div class="container-Fluid stickyColor">

<div class="container">

	<div>

	<ul>

		<li class=" wow pulse"><i class="fas fa-map-marker-alt stickyIcongreen"></i> D.No.78-16-7, Dhanalakshmi Textiles Street, Rajamahendravaram</li>

		<li class=" wow pulse"><a href="javascript:void();"><i class="fas fa-envelope stickyIcongreen"></i> info@yourmail.com</a></li>

		<li>

			Follow Us : <i class="fab fa-facebook-f"></i> <i class="fab fa-twitter"></i> <i class="fab fa-youtube"></i> <i class="fab fa-skype"></i> <i class="fab fa-linkedin-in"></i> |

			<a href="" target="_blank"><i class="fa fa-globe"></i> Google 360</a>

		</li>

	</ul>

	</div>

</div>

</div>

<!-- Ends here -->



<!-- Header Starts here -->

<div class="container clearFix">

	<div class="logoDiv  wow fadeInLeft" style="display: ;"><img src="images/ascent-hospital-logo.jpg" alt="Ascent Hospital" title="Ascent Hospital" width="100%"></div>

	<div class="menuIcon" id="menuIcn">

		<img src="images/menu-icn.png" alt="Ascent Hospital" title="Ascent Hospital" width="100%">

	</div>

	<div class="headeerBlk2 padLeftHeader  wow fadeInRight">

		<div class="openingDiv">

			<div class="timeIcon"><i class="far fa-clock timeIcon"></i></div>

			<div class="timeText">Opening Hours <span>Mon-Sat 09:00-22:00</span></div>

		</div>

		<div class="openingDiv">

			<div class="timeIcon"><i class="far fa-comment-dots timeIcon"></i></div>

			<div class="timeText">Call Us <span>+ 6123-3556-1208</span></div>

		</div>

	</div>

	<div class="makeApp wow fadeInRight">

		<a href="appointment.php"><i class="far fa-calendar-alt"></i> Make a Appointment</a>

	</div>

</div>

<!-- Ends here -->



<div class="clearFix"></div>



<div class="container-Fluid menu_bg wow fadeInUp">

<div class="container clearFix">

<div id='cssmenu' class="hidden-xs wow fadeInLeftBig">

<ul>

   <li><a href="index.php">Home</a></li>

   <li><a href="#">About Us</a>

			<ul class="sub-menu">

				<li><a href="doctors.php">Doctors</a></li>

				<li><a href="experts.php">Our Experts</a></li>

			</ul>

		

		</li>

		<li><a href="#.">Treatments</a>

			<ul class="sub-menu">

				<li><a href="breast_cancer.php">Breast Cancer Surgeries</a></li>

				<li><a href="gynae_oncology.php">Gynae Oncology</a></li>

				<li><a href="head_and_neck_oncology.php">Head and Neck Oncology</a></li>

				<li><a href="gastro_intestinal.php">Gastro Intestinal Surgeries</a></li>

				<li><a href="lung_cancer.php">Lung Cancer Surgeries</a></li>

				<li><a href="redical_nephrectomy.php">Radical Nephrectomy</a></li>

				<li><a href="medical_oncology.php">Medical Oncology Services</a></li>

			</ul>

		

		</li>

		<li><a href="services.php">Services</a></li>

		<li><a href="healthcheckups.php">Health Checkups</a></li>

		<li><a href="#.">Gallery</a>

			<ul class="sub-menu">

				<li><a href="photos.php">Photos</a></li>

				<li><a href="videos.php">Videos</a></li>

			</ul>

		</li>

		<li><a href="faqs.php">Faqs</a></li>

		<li><a href="reimbursement.php">Reimbursement</a></li>

		<li><a href="contactus.php">Contact us</a></li>

</ul>

</div>

</div>

</div>







<!-- Menu Starts here -->

<div class="menuDivMn clearFix visible-xs">

<div class="closeIconMenu closeIconDiv"><i class="fa fa-times" aria-hidden="true"></i></div>









<div class="menuInnDiv">

	<ul>

	

	<li><a href="index.php">Home</a></li>

   <li><a href="#.">About Us <i class="fa fa-angle-down"></i></a></li>

		

				<li><a href="doctors.php">&dash; Doctors</a></li>

				<li><a href="experts.php">&dash; Our Experts</a></li>

	

		

		

		<li><a href="#.">Treatments <i class="fa fa-angle-down"></i></a></li>

			

				<li><a href="breast_cancer.php">&dash; Breast Cancer Surgeries</a></li>

				<li><a href="gynae_oncology.php">&dash; Gynae Oncology</a></li>

				<li><a href="head_and_neck_oncology.php">&dash; Head and Neck Oncology</a></li>

				<li><a href="gastro_intestinal.php">&dash; Gastro Intestinal Surgeries</a></li>

				<li><a href="lung_cancer.php">&dash; Lung Cancer Surgeries</a></li>

				<li><a href="redical_nephrectomy.php">&dash; Radical Nephrectomy</a></li>

				<li><a href="medical_oncology.php">&dash; Medical Oncology Services</a></li>

		

		

		

		<li><a href="services.php">Services</a></li>

		<li><a href="healthcheckups.php">Health Checkups</a></li>

		<li><a href="#.">Gallery <i class="fa fa-angle-down"></i></a></li>

			

				<li><a href="photos.php">&dash; Photos</a></li>

				<li><a href="videos.php">&dash; Videos</a></li>

			

		

		<li><a href="faqs.php">Faqs</a></li>

		<li><a href="reimbursement.php">Reimbursement</a></li>

		<li><a href="contactus.php">Contact us</a></li>

	

	

		

	</ul>

</div>

</div>

<!-- Ends here -->

