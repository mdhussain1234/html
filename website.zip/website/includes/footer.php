
<!-- Footer Starts Here -->

<div class="container-Fluid footerBg wow tada">

<div class="container">

<div class="mobilePadd">

<div class="row">

		<div class="col-xs-4">

			<div class="padRow">

				<div class="logoDiv" style="display:;"><img src="images/ascent-hospital-logo-footer.jpg" alt="Ascent Hospital" title="Ascent Hospital" width="100%"></div>

				<div class="clearFix" style="padding-right: 10px;">

				<p>Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis  bibendum auctor.</p>

				<span class="readMoreTxt"><a href="javascript:void();">Read More</a></span>

				</div>

			</div>

		</div>



		<div class="col-xs-4">

			<div class="padRow">

				<h2 class="footerHDNG">Quick Links</h2>

				<div class="footerMenu">

					<ul>

						<li><a href="index.html">Home</a></li>

						<li><a href="aboutus.html">About Us</a></li>

						<li><a href="treatments.html">Treatments</a></li>

						<li><a href="services.html">Services</a></li>

						<li><a href="healthcheckups.html">Health Checkups</a></li>

						<li><a href="gallery.html">Gallery</a></li>

						<li><a href="faqs.html">Faqs</a></li>

						<li><a href="reimbursement.html">Reimbursement</a></li>

						<li><a href="contactus.html">Contact us</a></li>

					</ul>

				</div>

			</div>

		</div>



		<div class="col-xs-4 paddmobtop">

			<div class="padRow">

				<h2 class="footerHDNG">Opening Hours</h2>

				<p style="margin: 0px; padding: 0px;"><b>Monday – Friday</b> ------ 09:00-17:00</p>

				<p><b>Saturday</b> ----------------- 09:30-17:00</p>

				<p><b>Sunday</b> ------------------- 10:30-18:00</p>

			</div>

		</div>





</div>

</div>	

</div>

</div>

<!-- Ends here -->



<!---copyrights -->

<div class="copyrightsDiv alignCenter">

	Copyright &copy; 2018. All rights reserved | Designed By <a href="http://thecolourmoon.com/" target="_blank">Colourmoon</a></i>

</div>

<!-- Ends here -->



<script src="js/swiper.min.js"></script>

<script>

var swiper = new Swiper('.swiper-container', {

	pagination: '.swiper-pagination',

	loop: true,

	paginationClickable: true,

	spaceBetween: 0,

	autoplay:3000,

	autoplayDisableOnInteraction:false,

 });

</script>

<script type="text/javascript" src="https://code.jquery.com/jquery-1.8.2.js"></script>



<script src="js/script.js"></script>





<script type="text/javascript"  src="js/wow.js"></script>



<script type="text/javascript">

(function($,sr){



  var debounce = function (func, threshold, execAsap) {

      var timeout;



      return function debounced () {

          var obj = this, args = arguments;

          function delayed () {

              if (!execAsap)

                  func.apply(obj, args);

              timeout = null; 

          };



          if (timeout)

              clearTimeout(timeout);

          else if (execAsap)

              func.apply(obj, args);



          timeout = setTimeout(delayed, threshold || 2); 

      };

  }

    // smartresize 

    jQuery.fn[sr] = function(fn){  return fn ? this.bind('resize', debounce(fn)) : this.trigger(sr); };



})(jQuery,'smartresize');

/*$(document).ready(function() {

	$( "#menuIcn" ).click(function() {

		$(".menuDiv").slideToggle();

		

	});

	$(window).smartresize(function(){  

		if($(window).width()>767){

			$(".menuDiv").css('display','block');

		}else{

			$(".menuDiv").css('display','none');

		}

	});

});*/

$(document).ready(function() {

	$( "#menuIcn" ).click(function() {

		$(".menuDivMn").css('display','block');

		$(".menuDivMn").animate({right: "0"},500);

	});

	$( ".closeIconDiv" ).click(function() {

		$(".menuDivMn").animate({right: "-270"},500);

	});

	

});

</script>







<script type="text/javascript">

$(window).load(function() {

$("#loading").delay(5000).fadeOut(500);

});

wow = new WOW(

{

animateClass: 'animated',

offset:       100,

callback:     function(box) {

console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")

}

}

);

wow.init();

/* Set the width of the side navigation to 250px */

function openNav() {

document.getElementById("mySidenav").style.width = "300px";

}

/* Set the width of the side navigation to 0 */

function closeNav() {

document.getElementById("mySidenav").style.width = "0";

}

$('.datepicker').datetimepicker({

formatTime:'H:i',

formatDate:'d.m.Y',

defaultTime:'10:00',

timepickerScrollbar:false

});

</script>





<script type='text/javascript'>

$(function(){

var overlay = $('<div id="overlay"></div>');

overlay.show();

overlay.appendTo(document.body);

$('.popup').show();

$('.close').click(function(){

$('.popup').hide();

overlay.appendTo(document.body).remove();

return false;

});





 



$('.x').click(function(){

$('.popup').hide();

overlay.appendTo(document.body).remove();

return false;

});

});

</script>



</body>

</html>