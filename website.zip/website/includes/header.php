<!DOCTYPE html>

<html>

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

<title>:: Ascent Hospital ::</title>

<link rel="stylesheet" href="css/style.css">

<link rel="stylesheet" href="css/responsive.css">

<link rel="stylesheet" href="css/all.css">

<link rel="stylesheet" href="swiper.min.css">

 <link rel="stylesheet" type="text/css" href="css/animate.css">

 