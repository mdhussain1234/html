<div class='popup hidden-xs'>

<div class='cnt223'>





<div class="row">

	<div class="wow fadeInLeft">

		<div class="padRow">

		<img src="images/popup_pic.jpg" class="img-thumbnail img-responsive" style="margin-left: -10px;">

		</div>

	</div>

	

</div>







<p align="center">

<a href='' class='close'>Close</a>

</p>

</div>

</div>
