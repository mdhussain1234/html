<?php include 'includes/header.php'; ?><?php	include 'includes/header_1.php';?><?php	include 'includes/header_3.php';  ?>
<!-- Banner Starts here -->
<div class="container-Fluid bannerInner">
	<div class="bannerInnerShade">
		<div class="innerMainHead wow zoomInUp">Our Experts <span><a href="index.html">Home</a> - About Us</span></div>
	</div>
	<img src="images/slide-1.jpg" width="100%" style="min-height: 360px;">
</div>
<!-- Ends here -->

<!-- About Us Starts here -->
<div class="container">
<div class="mobilePadd">

<br>
<div class="row ">
	<div class="row">
	<div class="col-xs-3 wow fadeInRight">
	<div class="padRow">
		<div class="expertDocBlk">
			<div style="position:absolute; bottom: 0px;"><img src="images/expert-shape.png" width="100%"></div>
			<img src="images/expert-doc.jpg" width="100%">
		</div>
		<div class="expertDocContent">
			Dr. J.Srinivas, M.S.,M.Ch <span>Surgical Gastroenterology</span>
		</div>
	</div>
	</div>

	<div class="col-xs-3 wow fadeInRight">
	<div class="padRow">
		<div class="expertDocBlk">
			<div style="position:absolute; bottom: 0px;"><img src="images/expert-shape.png" width="100%"></div>
			<img src="images/expert-doc1.jpg" width="100%">
		</div>
		<div class="expertDocContent">
			Dr. CH.S.Prabhu, M.S.,M.Ch <span>Surgical Gastroenterology</span>
		</div>
	</div>
	</div>

	<div class="col-xs-3 wow fadeInRight">
	<div class="padRow">
		<div class="expertDocBlk">
			<div style="position:absolute; bottom: 0px;"><img src="images/expert-shape.png" width="100%"></div>
			<img src="images/expert-doc2.jpg" width="100%">
		</div>
		<div class="expertDocContent">
			Dr. Sonal Asthana, M.S., M.Ch <span>Head Dept. Liver Transplant, Aster CMI Hospital, Bangalore</span>
		</div>
	</div>
	</div>

	<div class="col-xs-3 wow fadeInRight">
	<div class="padRow">
		<div class="expertDocBlk">
			<div style="position:absolute; bottom: 0px;"><img src="images/expert-shape.png" width="100%"></div>
			<img src="images/expert-doc3.jpg" width="100%">
		</div>
		<div class="expertDocContent">
			Dr. A.V.S. Suresh, MD.DM <span>Medical Oncology</span>
		</div>
	</div>
	</div>
</div>
	<div class="clearFix"></div>
	
	
	<div class="row">
	<div class="col-xs-3 wow fadeInLeft">
	<div class="padRow">
		<div class="expertDocBlk">
			<div style="position:absolute; bottom: 0px;"><img src="images/expert-shape.png" width="100%"></div>
			<img src="images/expert-doc4.jpg" width="100%">
		</div>
		<div class="expertDocContent">
			Dr. V.Sree Ramulu, MD.DM <span>Medical Gastroenterology</span>
		</div>
	</div>
	</div>

	<div class="col-xs-3 wow fadeInLeft">
	<div class="padRow">
		<div class="expertDocBlk">
			<div style="position:absolute; bottom: 0px;"><img src="images/expert-shape.png" width="100%"></div>
			<img src="images/expert-doc5.jpg" width="100%">
		</div>
		<div class="expertDocContent">
			Dr. A.R.Kiran Kumar, M.D <span>Radiation Oncology</span>
		</div>
	</div>
	</div>

	<div class="col-xs-3 wow fadeInLeft">
	<div class="padRow">
		<div class="expertDocBlk">
			<div style="position:absolute; bottom: 0px;"><img src="images/expert-shape.png" width="100%"></div>
			<img src="images/expert-doc6.jpg" width="100%">
		</div>
		<div class="expertDocContent">
			Dr. R.V.Ravi, M.S.,M.Ch <span>Nuero Surgery</span>
		</div>
	</div>
	</div>

	<div class="col-xs-3 wow fadeInLeft">
	<div class="padRow">
		<div class="expertDocBlk">
			<div style="position:absolute; bottom: 0px;"><img src="images/expert-shape.png" width="100%"></div>
			<img src="images/expert-doc6.jpg" width="100%">
		</div>
		<div class="expertDocContent">
			Dr.N.V.N. Rao, M.S <span>Orthopedics</span>
		</div>
	</div>
	</div>
</div>
<div class="clearFix"></div>
	
	
	<div class="row">
	<div class="col-xs-3  wow fadeInRight">
	<div class="padRow">
		<div class="expertDocBlk">
			<div style="position:absolute; bottom: 0px;"><img src="images/expert-shape.png" width="100%"></div>
			<img src="images/expert-doc6.jpg" width="100%">
		</div>
		<div class="expertDocContent">
			Dr.M.Uday Kiran, M.S <span>General Surgery</span>
		</div>
	</div>
	</div>

	<div class="col-xs-3 wow fadeInRight">
	<div class="padRow">
		<div class="expertDocBlk">
			<div style="position:absolute; bottom: 0px;"><img src="images/expert-shape.png" width="100%"></div>
			<img src="images/expert-doc6.jpg" width="100%">
		</div>
		<div class="expertDocContent">
			Dr.T.K.Raju, MD <span>General Medicine</span>
		</div>
	</div>
	</div>

	
</div>
	<div class="clearFix"></div>
</div>

<br><br><br><br>



</div>
</div>
<!-- ends here -->
<?php	include 'includes/footer.php';  ?>