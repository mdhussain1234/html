<?php include 'includes/header.php'; ?><?php	include 'includes/header_1.php';?><?php	include 'includes/header_3.php';  ?>

<!-- Banner Starts here -->
<div class="container-Fluid bannerInner">
	<div class="bannerInnerShade">
		<div class="innerMainHead wow zoomInUp">Doctors <span><a href="index.html">Home</a> - About Us</span></div>
	</div>
	<img src="images/slide-1.jpg" width="100%" style="min-height: 360px;">
</div>
<!-- Ends here -->

<!-- About Us Starts here -->
<div class="container">
<div class="mobilePadd">

<br>
<br>
<div class="row img-thumbnail  wow fadeInRight">
	<div class="col-xs-3">
		<div class="padRow">
		<img src="images/doctor_2.jpg" width="100%">
		</div>
	</div>
	<div class="col-xs-9 ">
		<div class="padRow">
		<h1>Dr. GUDDANTI SRIDEVI <span>Medical Oncologist (A.I.I.M.S. New Delhi, Tata Memorial Hospital) <br>
		& Managing Director <br>ASCENT HOSPITALS</span></h1>
		
		</div>
	
		
	</div>
	<div class="clearFix"></div>
</div>

</div>
</div>
<!-- ends here -->
<?php	include 'includes/footer.php';  ?>